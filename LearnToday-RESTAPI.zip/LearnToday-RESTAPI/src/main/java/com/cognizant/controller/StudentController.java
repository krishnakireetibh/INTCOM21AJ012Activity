package com.cognizant.controller;

public class StudentController {

}
