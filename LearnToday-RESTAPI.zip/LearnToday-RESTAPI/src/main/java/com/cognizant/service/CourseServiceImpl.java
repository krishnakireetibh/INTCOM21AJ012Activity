package com.cognizant.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.stereotype.Service;

import com.cognizant.dao.CourseDAOImpl;
import com.cognizant.model.Course;

@Service
public class CourseServiceImpl implements CourseService {
	
	@Autowired
	CourseDAOImpl courseDAOImpl;
	
	DriverManagerDataSource dataSource;
	
	public DriverManagerDataSource getDataSource()
	{
		dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName("com.mysql.cj.jdbc.Driver");
		dataSource.setUrl("jdbc:mysql://localhost:3306/ctsdata01");
		dataSource.setUsername("root");
		dataSource.setPassword("Kireeti@1352");
		return dataSource;
	}
	
	@Override
	public List <Course> getAllCourses()
	{
		dataSource = getDataSource();
		courseDAOImpl = new CourseDAOImpl(dataSource);
		return courseDAOImpl.getAllCourses();
	}

	@Override
	public Course getCourseById(int courseId) {
		// TODO Auto-generated method stub
		dataSource = getDataSource();
		courseDAOImpl = new CourseDAOImpl(dataSource);
		return courseDAOImpl.getCourseById(courseId);
	}

}
