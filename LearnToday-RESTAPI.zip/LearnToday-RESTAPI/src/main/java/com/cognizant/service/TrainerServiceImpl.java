package com.cognizant.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.dao.TrainerDAO;
import com.cognizant.model.Trainer;

@Service
public class TrainerServiceImpl implements TrainerService {

	@Autowired
	TrainerDAO trainerDAO;
	
	@Override
	public boolean trainerSignUp(Trainer t) {
		// TODO Auto-generated method stub
		return trainerDAO.trainerSignUp(t);
	}

	@Override
	public String updatePassword(int id, Trainer t) {
		// TODO Auto-generated method stub
		return trainerDAO.updatePassword(id, t);
	}

}
