package com.cognizant.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.stereotype.Service;

import com.cognizant.dao.StudentDAOImpl;
import com.cognizant.model.Course;
import com.cognizant.model.Student;

@Service
public class StudentServiceImpl implements StudentService{

	@Autowired
	StudentDAOImpl studentDAOImpl;
	
	DriverManagerDataSource dataSource;
	
	public DriverManagerDataSource getDataSource()
	{
		dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName("com.mysql.cj.jdbc.Driver");
		dataSource.setUrl("jdbc:mysql://localhost:3306/ctsdata01");
		dataSource.setUsername("root");
		dataSource.setPassword("Kireeti@1352");
		return dataSource;
	}
	
	@Override
	public List<Course> getAllCourses() {
		// TODO Auto-generated method stub
		dataSource = getDataSource();
		studentDAOImpl = new StudentDAOImpl(dataSource);
		return studentDAOImpl.getAllCourses();
	}

	@Override
	public boolean postStudent(Student s) {
		// TODO Auto-generated method stub
		dataSource = getDataSource();
		studentDAOImpl = new StudentDAOImpl(dataSource);
		return studentDAOImpl.postStudent(s);
	}

	@Override
	public boolean deleteStudent(int enrollmentId) {
		// TODO Auto-generated method stub
		dataSource = getDataSource();
		studentDAOImpl = new StudentDAOImpl(dataSource);
		return studentDAOImpl.deleteStudent(enrollmentId);
	}
	
}
