package com.cognizant.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.stereotype.Repository;

import com.cognizant.model.Trainer;

@Repository
public class TrainerDAOImpl implements TrainerDAO {
	
	private JdbcTemplate template;

	public TrainerDAOImpl(DataSource dataSource) {
		this.template = new JdbcTemplate(dataSource);
	}

	@Override
	public boolean trainerSignUp(Trainer t) {
		// TODO Auto-generated method stub
		int signedIn = 0;
		
		String sql = "INSERT INTO Trainer VALUES(?,?)";
		signedIn = template.update(sql,t.getTrainerId(),t.getPassword());
		if(signedIn == 0)
		{
			return false;
		}
		return true;
	}

	@Override
	public String updatePassword(int id, Trainer t) {
		// TODO Auto-generated method stub
		
		Trainer trainer = template.query("SELECT * FROM Trainer WHERE trainerId ="+id, new ResultSetExtractor<Trainer>() {

			@Override
			public Trainer extractData(ResultSet rs) throws SQLException, DataAccessException {
				// TODO Auto-generated method stub
				Trainer trainer = new Trainer();
				while (rs.next()) 
				{
					trainer.setTrainerId(id);
					trainer.setPassword(rs.getString(2));
					return trainer;
				}
				return null;
			}
		});
		if(trainer==null)
		{
			return "Trainer Not Found";
		}
		int update = 0;
		update = template.update("UPDATE Trainer SET password=? WHERE trainerId=?",t.getPassword(), id);
		if (update == 0)
		{
			return "Error";
		}
		return "Updated";
	}

}
