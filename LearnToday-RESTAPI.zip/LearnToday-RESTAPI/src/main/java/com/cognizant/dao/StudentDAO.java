package com.cognizant.dao;

import java.util.List;

import com.cognizant.model.Student;
import com.cognizant.model.Course;

public interface StudentDAO {
	
	public List <Course> getAllCourses();
	
	public boolean postStudent(Student s);
	
	public boolean deleteStudent(int enrollmentId);

}
