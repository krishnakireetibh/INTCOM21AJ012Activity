package com.cognizant.dao;

import java.util.List;

import com.cognizant.model.Course;

public interface CourseDAO {
	
	public List <Course> getAllCourses();
	
	public Course getCourseById(int courseId);

}
