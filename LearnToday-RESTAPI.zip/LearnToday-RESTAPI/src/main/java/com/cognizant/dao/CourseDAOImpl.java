package com.cognizant.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.stereotype.Repository;

import com.cognizant.model.Course;

@Repository
public class CourseDAOImpl implements CourseDAO {
	
	private JdbcTemplate template;
	
	public CourseDAOImpl(DataSource dataSource) {
		this.template = new JdbcTemplate(dataSource);
	}

	@Override
	public List<Course> getAllCourses() {
		// TODO Auto-generated method stub
		String sql = "SELECT * FROM Course";
		
		ResultSetExtractor<List<Course>> extractor = new ResultSetExtractor<List<Course>>() {
			
			@Override
			public List<Course> extractData(ResultSet rs) throws SQLException, DataAccessException {
				
				List<Course> courseList = new ArrayList<Course>();
				
				while(rs.next())
				{
					Course c = new Course();
					c.setCourseId(rs.getInt(1));
					c.setTitle(rs.getString(2));
					c.setFees(rs.getFloat(3));
					c.setDescription(rs.getString(4));
					c.setTrainer(rs.getString(5));
					c.setStartDate(rs.getDate(6));
					courseList.add(c);
				}
				return courseList;
			}
		};
		
		return template.query(sql, extractor);
	}

	@Override
	public Course getCourseById(int courseId) {
		// TODO Auto-generated method stub
		
		List<Course> courseList = getAllCourses();
		for(Course course : courseList)
		{
			if(course.getCourseId() == courseId)
			{
				return course;
			}
		}
		
		return null;
	}
	
}
